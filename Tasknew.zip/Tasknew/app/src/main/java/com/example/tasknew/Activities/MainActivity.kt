package com.example.tasknew.Activities

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ProgressBar
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.tasknew.Adapter.ListingMain
import com.example.tasknew.Models.SuccessModel
import com.example.tasknew.NetworkLayer.RetrofitClient
import com.example.tasknew.NetworkLayer.WebServices
import com.example.tasknew.R
import com.example.tasknew.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Response
import retrofit2.Retrofit

class MainActivity : AppCompatActivity()
{
    private lateinit var binding:ActivityMainBinding
    private lateinit var listingMain: ListingMain
    var showList = ArrayList<SuccessModel>()

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        val process :ProgressDialog = ProgressDialog(this)
        process.setTitle("Loading")
        process.show()


        binding.rec.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        listingMain = ListingMain(showList,this)
        binding.rec.adapter = listingMain
        val retrofit: Retrofit = RetrofitClient.getInstance()
        val request: WebServices = retrofit.create(WebServices::class.java)

        val call: Call<List<SuccessModel>> = request.getFace()
        call.enqueue(object : retrofit2.Callback<List<SuccessModel>> {
            override fun onResponse(call: Call<List<SuccessModel>>, response: Response<List<SuccessModel>>) {
                //Toast.makeText(this@MainActivity,""+response.body()!!.size,Toast.LENGTH_LONG).show()

                for (i in 0 until response.body()!!.size)
                {
                    response.body()!!.get(i).let { showList.addAll(listOf(it)) }
                }
                listingMain.notifyDataSetChanged()
                process.dismiss()


            }

            override fun onFailure(call: Call<List<SuccessModel>>, t: Throwable) {
                Toast.makeText(this@MainActivity,""+t.message,Toast.LENGTH_LONG).show()
                process.dismiss()
                //System.exit(0)
            }
        })

    }
}
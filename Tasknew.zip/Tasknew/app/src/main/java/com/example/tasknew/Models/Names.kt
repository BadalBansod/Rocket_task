package com.example.tasknew.Models

data class Names(
    var name:String = ""
)

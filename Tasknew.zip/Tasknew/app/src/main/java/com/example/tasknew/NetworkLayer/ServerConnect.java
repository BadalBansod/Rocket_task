package com.example.tasknew.NetworkLayer;


public class ServerConnect {
    public static final String BASE_URL = "https://api.spacexdata.com/v4/";
}
//122.169.115.179/Home all
//192.168.0.104/local ip
package com.example.tasknew.Models

class SuccessModel
{
    val name:String=""
    val id:String=""
    val country:String=""
    val active:String=""
    val cost_per_launch:String=""
    val wikipedia:String=""
    val success_rate_pct:String=""
    val description:String=""
    val engines = engines()
    val height = height()
    val diameter = diameter()
    val flickr_images = ArrayList<String>()
}
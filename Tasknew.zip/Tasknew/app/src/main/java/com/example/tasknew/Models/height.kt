package com.example.tasknew.Models

data class height (
    val meters:String= "",
    val feet:String= ""

)
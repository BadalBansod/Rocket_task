package com.example.tasknew.Activities

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.tasknew.Adapter.SliderAdapterExample
import com.example.tasknew.Models.SuccessModel
import com.example.tasknew.NetworkLayer.RetrofitClient
import com.example.tasknew.NetworkLayer.WebServices
import com.example.tasknew.R
import com.example.tasknew.databinding.ActivityDetailsMainBinding
import retrofit2.Call
import retrofit2.Response
import retrofit2.Retrofit

class DetailsMain : AppCompatActivity() {
    private lateinit var binding:ActivityDetailsMainBinding
    lateinit var urlList: ArrayList<String>
    private lateinit var process: ProgressDialog
    var position=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        binding = DataBindingUtil.setContentView(this, R.layout.activity_details_main)

      process  = ProgressDialog(this)
        if (intent!=null)
        {
           // Toast.makeText(this,""+intent.getStringExtra("ids"),Toast.LENGTH_LONG).show()
            process.setTitle("Loading")
            process.show()
            getDetails(intent.getStringExtra("ids").toString())
        }
        binding.link.setSelected(true)
        urlList = java.util.ArrayList<String>()
        binding.back.setOnClickListener {
            onBackPressed()
            finish()
        }

    }

    private fun getDetails(stringExtra: String)
    {
        val retrofit: Retrofit = RetrofitClient.getInstance()
        val request: WebServices = retrofit.create(WebServices::class.java)

        val call: Call<SuccessModel> = request.getDetails(stringExtra.toString())
        call.enqueue(object : retrofit2.Callback<SuccessModel> {
            override fun onResponse(call: Call<SuccessModel>, response: Response<SuccessModel>) {
                //Toast.makeText(this@DetailsMain,""+response.body()!!.flickr_images,Toast.LENGTH_LONG).show()
                response.body()!!.flickr_images.let { urlList.addAll(it) }
                binding.title.setText(response.body()!!.name.toString())
                val adapter = SliderAdapterExample(this@DetailsMain, urlList)
                binding.imageSlider.setSliderAdapter(adapter)
                binding.imageSlider.scrollTimeInSec = 4
                binding.height.setText("${response.body()!!.height.meters} / ${response.body()!!.height.feet}")
                binding.diameters.setText("${response.body()!!.diameter.meters} / ${response.body()!!.diameter.feet}")
                binding.descc.setText(response.body()!!.description)
                binding.successper.setText("${response.body()!!.success_rate_pct} %")
                binding.costlaunch.setText(response.body()!!.cost_per_launch)
                binding.link.setText(response.body()!!.wikipedia)


                if (response.body()!!.active.equals("false"))
                {
                    binding.status.setText("In-Active")
                }
                else{
                    binding.status.setText("Active")
                }
                process.dismiss()


            }

            override fun onFailure(call: Call<SuccessModel>, t: Throwable) {
                Toast.makeText(this@DetailsMain,""+t.message,Toast.LENGTH_LONG).show()
                process.dismiss()
            }
        })

    }
}
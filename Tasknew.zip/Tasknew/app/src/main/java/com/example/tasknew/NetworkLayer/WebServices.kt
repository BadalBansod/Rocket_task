package com.example.tasknew.NetworkLayer

import com.example.tasknew.Models.SuccessModel
import retrofit2.Call
import retrofit2.http.*


interface WebServices {


    @GET("rockets")
    fun getFace(): Call<List<SuccessModel>>


    @GET("rockets/{id}")
    fun getDetails(@Path("id") id:String): Call<SuccessModel>

}

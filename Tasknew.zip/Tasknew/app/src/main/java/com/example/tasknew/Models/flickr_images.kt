package com.example.tasknew.Models

data class flickr_images(
     val data:String = listOf<String>().toString()
)
package com.example.tasknew.Adapter

import android.content.Context
import android.content.Intent
import android.media.Image
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.tasknew.Activities.DetailsMain
import com.example.tasknew.Models.SuccessModel
import com.example.tasknew.R

class ListingMain(private val mList: ArrayList<SuccessModel>, var context: Context) :
    RecyclerView.Adapter<ListingMain.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.service_layout, parent, false)

        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val objectMain = mList[position]
        holder.name.setText("Name : ${objectMain.name}")
        holder.name.setSelected(true)
        holder.country.setSelected(true)
        holder.enginecount.setSelected(true)
        holder.country.setText("Country : ${objectMain.country}")
        holder.enginecount.setText("Count Engines : ${objectMain.engines.number}")
        Glide.with(context).load(objectMain.flickr_images.get(0)).placeholder(R.drawable.pngegg).into(holder.image)
        holder.itemView.setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {
                context.startActivity(Intent(context,DetailsMain::class.java).putExtra("ids",objectMain.id.toString()))
            }
        })
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val name: TextView = itemView.findViewById(R.id.name)
        val country: TextView = itemView.findViewById(R.id.country)
        val enginecount: TextView = itemView.findViewById(R.id.enginecount)
        val image: ImageView = itemView.findViewById(R.id.image)

    }
}

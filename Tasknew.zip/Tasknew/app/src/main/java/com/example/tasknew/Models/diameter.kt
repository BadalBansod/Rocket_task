package com.example.tasknew.Models

data class diameter(
    val meters:String= "",
    val feet:String= ""
)
